<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BuyerMessageDefaultResponse extends Model
{
    protected $guarded = [];
}
