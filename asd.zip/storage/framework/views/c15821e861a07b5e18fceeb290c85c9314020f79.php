<?php $__env->startComponent('mail::message'); ?>


<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
<img src="<?php echo e($logoUrl); ?>" alt="Logo" style="height: 50px;">
<?php if (isset($__componentOriginala6c60a8eadc3b56c524581de8cda10d4f5a799b4)): ?>
<?php $component = $__componentOriginala6c60a8eadc3b56c524581de8cda10d4f5a799b4; ?>
<?php unset($__componentOriginala6c60a8eadc3b56c524581de8cda10d4f5a799b4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>


<?php $__currentLoopData = $body; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(isset($section['title'])): ?>

### <?php echo e($section['title']); ?>


<?php endif; ?>
<?php if(isset($section['content'])): ?>
<?php echo e($section['content']); ?>


<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
<span style="font-size: 12px; color: #888;">
<?php echo e($footer ?? '© ' . date('Y') . ' comerciocity. Todos los derechos reservados.'); ?>

</span>
<?php if (isset($__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c)): ?>
<?php $component = $__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c; ?>
<?php unset($__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\tienda-api\resources\views/emails/common-mail.blade.php ENDPATH**/ ?>