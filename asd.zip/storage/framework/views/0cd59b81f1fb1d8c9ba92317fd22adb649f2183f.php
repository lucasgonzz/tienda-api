<?php $__env->startComponent('mail::message'); ?>
# Nuevo Pedido

Has recibido un nuevo pedido de tu tienda de <?php echo e($order->buyer->name); ?>.

<?php $__env->startComponent('mail::button', ['url' => $order->user->default_version . '/online/pedidos']); ?>
Ir a PEDIDOS
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


¡Que tengas un lindo dia!<br>
ComercioCity

<?php $__env->startComponent('mail::footer'); ?>
© <?php echo e(date('Y')); ?> ComercioCity. Todos los derechos reservados.
<?php if (isset($__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c)): ?>
<?php $component = $__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c; ?>
<?php unset($__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\tienda-api\resources\views/emails/order-created.blade.php ENDPATH**/ ?>