<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\tienda-api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>