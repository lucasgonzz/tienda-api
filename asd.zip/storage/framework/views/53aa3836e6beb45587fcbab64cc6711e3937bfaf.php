<?php $__env->startComponent('mail::layout'); ?>

<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ['url' => $commerce->online]); ?>
<img src="<?php echo e($logo_url); ?>" class="logo" alt="<?php echo e($commerce->company_name); ?> Logo">
<?php if (isset($__componentOriginala6c60a8eadc3b56c524581de8cda10d4f5a799b4)): ?>
<?php $component = $__componentOriginala6c60a8eadc3b56c524581de8cda10d4f5a799b4; ?>
<?php unset($__componentOriginala6c60a8eadc3b56c524581de8cda10d4f5a799b4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<p>
	Has solicitado que te enviemos un código para recuperar tu contraseña.
</p>
<p>
	Aquí debajo te dejamos el código para que valides tu cuenta y puedas cambiar tu contraseña.
</p>

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($code); ?>

<?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
© <?php echo e(date('Y')); ?> ComercioCity
<?php if (isset($__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c)): ?>
<?php $component = $__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c; ?>
<?php unset($__componentOriginala991192d5a5d5f731a8cf5f31528af3b372f333c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>

<?php if (isset($__componentOriginalc32b54e0a3261a2d3631146e856277520bd12d21)): ?>
<?php $component = $__componentOriginalc32b54e0a3261a2d3631146e856277520bd12d21; ?>
<?php unset($__componentOriginalc32b54e0a3261a2d3631146e856277520bd12d21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\tienda-api\resources\views/emails/password-reset.blade.php ENDPATH**/ ?>