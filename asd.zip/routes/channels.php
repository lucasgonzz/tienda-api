<?php

use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

// Broadcast::channel('App.User.{id}', function ($user, $id) {
//     return (int) $user->id === (int) $id;
// });

// Broadcast::channel('order.{buyer_id}', function () {
// 	return true; //Always return true or false
// });
// Broadcast::channel('question.{buyer_id}', function () {
// 	return true; //Always return true or false
// });

// Broadcast::channel('orderChannel', function () {
// 	return true; //Always return true or false
// });

// Broadcast::channel('questionChannel', function () {
// 	return true; //Always return true or false
// });
