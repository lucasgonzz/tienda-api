<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\tienda-api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>