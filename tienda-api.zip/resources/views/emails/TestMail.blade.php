<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Titulo del mail</title>
</head>
<body>
	<h1>{{ $details['title'] }}</h1>
	<p>{{ $details['body'] }}</p>
	<p>Gracias</p>
</body>
</html>