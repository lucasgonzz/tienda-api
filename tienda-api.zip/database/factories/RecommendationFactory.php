<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Recommendation;
use Faker\Generator as Faker;

$factory->define(Recommendation::class, function (Faker $faker) {
    return [
        //
    ];
});
