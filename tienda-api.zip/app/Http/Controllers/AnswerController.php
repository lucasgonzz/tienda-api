<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnswerController extends Controller
{
  //   function procesarPago($token, $pedido) {
		// MercadoPago\SDK::setAccessToken(env('ENV_ACCESS_TOKEN'));

		// $payment = new MercadoPago\Payment();
		// $payment->token = $token;
		// $payment->transaction_amount = $pedido->amount;
		// $payment->description = $pedido->description;
		// $payment->installments = $pedido->installments;
		// $payment->payment_method_id = $pedido->payment_method_id;
		// $payment->issuer_id = $pedido->issuer_id;
		// $payment->payer = array(
		// 	"email" => $pedido->user->email
		// );
		// // Guarda y postea el pago
		// $payment->save();
		// // Imprime el estado del pago
		// echo $payment->status;
  //   }
}
