<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Platelet extends Model
{
    //
}
