<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LastSearch extends Model
{
    protected $guarded = [];
}
