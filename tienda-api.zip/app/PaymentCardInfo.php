<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentCardInfo extends Model
{
    protected $guarded = [];
}
