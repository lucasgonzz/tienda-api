<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArticlePropertyType extends Model
{
    //
}
